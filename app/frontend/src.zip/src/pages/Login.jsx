import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

/* Tela de login principal (home pública) */
export default function Login() {
  const { login } = useAuth();
  const nav = useNavigate();
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");
  const [err, setErr] = useState("");

  async function handleSubmit(e) {
    e.preventDefault();
    setErr("");
    const res = await login({ email, senha });
    if (res.ok) {
      nav("/home");
    } else {
      setErr("Erro ao autenticar");
    }
  }

  return (
    <div className="auth-page">
      <div className="auth-card">
        <h2>Bem-vindo ao Dropverse</h2>
        <p className="muted">Entre para acessar sua loja e feed</p>

        {err && <div className="error">{err}</div>}

        <form onSubmit={handleSubmit}>
          <input placeholder="E-mail" value={email} onChange={e=>setEmail(e.target.value)} required />
          <input placeholder="Senha" type="password" value={senha} onChange={e=>setSenha(e.target.value)} required />
          <button className="btn">Entrar</button>
        </form>

        <div className="auth-links">
          <Link to="/register">Criar conta</Link>
        </div>
      </div>
    </div>
  );
}
